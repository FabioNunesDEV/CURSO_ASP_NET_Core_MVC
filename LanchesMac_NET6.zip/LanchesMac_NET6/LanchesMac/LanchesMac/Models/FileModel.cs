﻿namespace LanchesMac.Models
{
    public class FileModel
    {
        public string FileName { get; set; }
    }
}
